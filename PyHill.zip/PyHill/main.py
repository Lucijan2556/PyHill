import pyhill.pyhill as ph

ph.attach()
ph.modify("x", 2.5)

while True:
    ph.updateGet("x")
    print(ph.get.x)